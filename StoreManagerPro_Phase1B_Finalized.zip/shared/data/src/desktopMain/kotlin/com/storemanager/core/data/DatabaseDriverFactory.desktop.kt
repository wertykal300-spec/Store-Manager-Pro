package com.storemanager.core.data

import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.Properties
import java.util.UUID

actual class DatabaseDriverFactory(
    private val dbFile: File? = null
) {
    internal var simulateTriggerFailure: Boolean = false
    internal var customTriggerScript: String? = null

    actual fun createDriver(): SqlDriver {
        val targetFile = dbFile ?: getDefaultDatabaseFile()
        val isNewDatabase = !targetFile.exists()

        if (isNewDatabase) {
            targetFile.parentFile?.mkdirs()
            initializeNewDatabaseAtomically(targetFile)
        }

        // Open connection to verified target file
        val properties = createConnectionProperties()
        val url = "jdbc:sqlite:${targetFile.absolutePath}"
        val driver = JdbcSqliteDriver(url, properties)

        // Apply mandatory connection-level PRAGMAs on every connection
        applyConnectionPragmas(driver)

        if (!isNewDatabase) {
            // Validate existing database before declaring it ready
            try {
                validateExistingDatabase(driver)
            } catch (e: Throwable) {
                try { driver.close() } catch (_: Throwable) {}
                // Never delete or wipe existing file on validation rejection
                throw e
            }
        }

        return driver
    }

    private fun createConnectionProperties(): Properties {
        return Properties().apply {
            put("foreign_keys", "true")
            put("busy_timeout", "10000") // 10 seconds busy timeout
            put("journal_mode", "WAL")   // Write-Ahead Logging for high concurrency & safe crash-durability
            put("synchronous", "NORMAL") // Safe crash durability with WAL mode
        }
    }

    private fun applyConnectionPragmas(driver: SqlDriver) {
        driver.execute(null, "PRAGMA foreign_keys = ON;", 0)
        driver.execute(null, "PRAGMA busy_timeout = 10000;", 0)
        driver.execute(null, "PRAGMA journal_mode = WAL;", 0)
        driver.execute(null, "PRAGMA synchronous = NORMAL;", 0)
    }

    private fun initializeNewDatabaseAtomically(targetFile: File) {
        val parentDir = targetFile.parentFile ?: File(".")
        val stagingFile = File(
            parentDir,
            "${targetFile.name}.staging.${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
        )

        var stagingDriver: SqlDriver? = null
        try {
            val properties = createConnectionProperties()
            val stagingUrl = "jdbc:sqlite:${stagingFile.absolutePath}"
            stagingDriver = JdbcSqliteDriver(stagingUrl, properties)

            // Apply connection pragmas to staging connection
            applyConnectionPragmas(stagingDriver)

            // 1. Create 55 Tables and 107 explicit unique/functional indexes from SQLDelight schema
            StoreDatabase.Schema.create(stagingDriver)

            // 2. Execute 186 canonical triggers
            if (simulateTriggerFailure) {
                // Simulate partial failure mid-trigger execution for testing atomicity
                val script = customTriggerScript ?: loadCanonicalTriggerScript()
                val parts = script.split("CREATE TRIGGER").filter { it.trim().isNotBlank() }
                for (i in 0 until (parts.size / 2).coerceAtLeast(1)) {
                    val statement = "CREATE TRIGGER " + parts[i].trim()
                    stagingDriver.execute(null, statement, 0)
                }
                throw IllegalStateException("Simulated mid-trigger failure during database initialization")
            } else {
                val script = customTriggerScript ?: loadCanonicalTriggerScript()
                executeTriggerScript(stagingDriver, script)
            }

            // 3. Validate newly initialized staging schema before setting user_version
            validateCountsAndIntegrity(stagingDriver)

            // 4. Mark database baseline version
            stagingDriver.execute(null, "PRAGMA user_version = $EXPECTED_USER_VERSION;", 0)

            // 5. Truncate WAL checkpoint to ensure all staging changes are cleanly flushed into the main db file
            stagingDriver.execute(null, "PRAGMA wal_checkpoint(TRUNCATE);", 0)

            // Close staging driver cleanly before atomic move
            stagingDriver.close()
            stagingDriver = null

            // Clean staging wal/shm if present after close
            cleanSidecarFiles(stagingFile)

            // Atomically move staging file to target file
            try {
                Files.move(
                    stagingFile.toPath(),
                    targetFile.toPath(),
                    StandardCopyOption.ATOMIC_MOVE
                )
            } catch (_: Exception) {
                // Fallback to REPLACE_EXISTING if ATOMIC_MOVE is not supported across filesystem boundaries
                Files.move(
                    stagingFile.toPath(),
                    targetFile.toPath(),
                    StandardCopyOption.REPLACE_EXISTING
                )
            }
        } catch (e: Throwable) {
            // Safely close staging driver
            try { stagingDriver?.close() } catch (_: Throwable) {}
            // Clean up staging files completely
            cleanFileAndSidecars(stagingFile)
            // Ensure target file does NOT exist in incomplete state
            if (targetFile.exists() && targetFile.length() == 0L) {
                targetFile.delete()
            }
            throw DatabaseInitializationException(
                "Database initialization failed and was rolled back atomically: ${e.message}",
                e
            )
        }
    }

    private fun loadCanonicalTriggerScript(): String {
        val stream = this::class.java.classLoader.getResourceAsStream("canonical_triggers.sql")
            ?: error("canonical_triggers.sql resource not found in classpath")
        return stream.bufferedReader().use { it.readText() }
    }

    private fun executeTriggerScript(driver: SqlDriver, script: String) {
        val parts = script.split("CREATE TRIGGER")
        for (part in parts) {
            val trimmed = part.trim()
            if (trimmed.isNotBlank()) {
                val statement = "CREATE TRIGGER " + trimmed
                driver.execute(null, statement, 0)
            }
        }
    }

    private fun cleanSidecarFiles(baseFile: File) {
        val walFile = File("${baseFile.absolutePath}-wal")
        val shmFile = File("${baseFile.absolutePath}-shm")
        if (walFile.exists() && walFile.length() == 0L) walFile.delete()
        if (shmFile.exists() && shmFile.length() == 0L) shmFile.delete()
    }

    private fun cleanFileAndSidecars(baseFile: File) {
        if (baseFile.exists()) baseFile.delete()
        File("${baseFile.absolutePath}-wal").takeIf { it.exists() }?.delete()
        File("${baseFile.absolutePath}-shm").takeIf { it.exists() }?.delete()
    }

    fun validateExistingDatabase(driver: SqlDriver) {
        // 1. Verify PRAGMA user_version
        val userVersion = querySingleLong(driver, "PRAGMA user_version;")
        if (userVersion != EXPECTED_USER_VERSION) {
            throw DatabaseValidationException(
                "Invalid database user_version: found $userVersion, expected $EXPECTED_USER_VERSION. Database rejected."
            )
        }

        // 2. Validate tables, indexes, triggers, and SQLite integrity
        validateCountsAndIntegrity(driver)
    }

    private fun validateCountsAndIntegrity(driver: SqlDriver) {
        // Tables count
        val tableCount = querySingleLong(
            driver,
            "SELECT count(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"
        )
        if (tableCount != EXPECTED_TABLE_COUNT) {
            throw DatabaseValidationException(
                "Incomplete database schema: found $tableCount tables, expected $EXPECTED_TABLE_COUNT."
            )
        }

        // Indexes count
        val indexCount = querySingleLong(
            driver,
            "SELECT count(*) FROM sqlite_master WHERE type='index' AND sql IS NOT NULL;"
        )
        if (indexCount != EXPECTED_INDEX_COUNT) {
            throw DatabaseValidationException(
                "Incomplete database schema: found $indexCount explicit indexes, expected $EXPECTED_INDEX_COUNT."
            )
        }

        // Triggers count
        val triggerCount = querySingleLong(
            driver,
            "SELECT count(*) FROM sqlite_master WHERE type='trigger';"
        )
        if (triggerCount != EXPECTED_TRIGGER_COUNT) {
            throw DatabaseValidationException(
                "Incomplete database schema: found $triggerCount triggers, expected $EXPECTED_TRIGGER_COUNT."
            )
        }

        // Integrity check
        val integrityResult = querySingleString(driver, "PRAGMA integrity_check;")
        if (integrityResult != "ok") {
            throw DatabaseValidationException(
                "Database integrity check failed: $integrityResult"
            )
        }

        // Foreign key check
        val fkErrors = countRows(driver, "PRAGMA foreign_key_check;")
        if (fkErrors > 0) {
            throw DatabaseValidationException(
                "Database foreign key check failed with $fkErrors violations."
            )
        }
    }

    private fun querySingleLong(driver: SqlDriver, sql: String): Long {
        val cursor = driver.executeQuery<Long>(
            null,
            sql,
            {
                it.next()
                QueryResult.Value(it.getLong(0) ?: 0L)
            },
            0
        )
        return cursor.value
    }

    private fun querySingleString(driver: SqlDriver, sql: String): String? {
        val cursor = driver.executeQuery<String?>(
            null,
            sql,
            {
                it.next()
                QueryResult.Value(it.getString(0))
            },
            0
        )
        return cursor.value
    }

    private fun countRows(driver: SqlDriver, sql: String): Long {
        val cursor = driver.executeQuery<Long>(
            null,
            sql,
            {
                var count = 0L
                while (it.next().value) {
                    count++
                }
                QueryResult.Value(count)
            },
            0
        )
        return cursor.value
    }

    companion object {
        const val EXPECTED_TABLE_COUNT = 55L
        const val EXPECTED_INDEX_COUNT = 107L
        const val EXPECTED_TRIGGER_COUNT = 186L
        const val EXPECTED_USER_VERSION = 1L

        fun getDefaultDatabaseFile(): File {
            val os = System.getProperty("os.name").lowercase()
            val baseDir = when {
                os.contains("win") -> {
                    val appData = System.getenv("LOCALAPPDATA")
                        ?: (System.getProperty("user.home") + "\\AppData\\Local")
                    File(appData, "StoreManagerPro\\data")
                }
                os.contains("mac") -> {
                    File(System.getProperty("user.home"), "Library/Application Support/StoreManagerPro/data")
                }
                else -> { // Linux / Unix
                    val xdgData = System.getenv("XDG_DATA_HOME")
                    if (!xdgData.isNullOrBlank()) {
                        File(xdgData, "storemanagerpro/data")
                    } else {
                        File(System.getProperty("user.home"), ".local/share/storemanagerpro/data")
                    }
                }
            }
            return File(baseDir, "store_manager_master.db")
        }

        fun createInMemoryDriver(): SqlDriver {
            val properties = Properties().apply {
                put("foreign_keys", "true")
                put("busy_timeout", "10000")
            }
            val driver = JdbcSqliteDriver(JdbcSqliteDriver.IN_MEMORY, properties)
            driver.execute(null, "PRAGMA foreign_keys = ON;", 0)
            driver.execute(null, "PRAGMA busy_timeout = 10000;", 0)

            StoreDatabase.Schema.create(driver)

            val factory = DatabaseDriverFactory()
            val script = factory.loadCanonicalTriggerScript()
            factory.executeTriggerScript(driver, script)
            driver.execute(null, "PRAGMA user_version = $EXPECTED_USER_VERSION;", 0)

            return driver
        }

        fun getSqliteVersion(driver: SqlDriver): String {
            val cursor = driver.executeQuery<String>(
                null,
                "SELECT sqlite_version();",
                {
                    it.next()
                    QueryResult.Value(it.getString(0) ?: "UNKNOWN")
                },
                0
            )
            return cursor.value
        }
    }
}
